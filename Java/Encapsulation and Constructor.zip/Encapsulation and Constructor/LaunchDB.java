class DBConnectivity
{
	public DBConnectivity()
	{
		System.out.println("Connect to database");
	}
}



public class LaunchDB {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		DBConnectivity db=new DBConnectivity();
		

	}

}
