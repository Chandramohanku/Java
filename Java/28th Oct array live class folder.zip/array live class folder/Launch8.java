
public class Launch8 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		char a[]=new char[4];
		a[0]='a';
	}

}
