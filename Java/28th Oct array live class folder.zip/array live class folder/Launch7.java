
public class Launch7 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		int a[]=new int[3];
		
		a[0]=10;
		a[1]=20;
		a[2]=30;
		//Array in Java are guarded with boundaries
		//a[3]=40; lead to ArrayIndexOutOfBoundsException during runtime
		
		System.out.println("statment after array");

	}

}
