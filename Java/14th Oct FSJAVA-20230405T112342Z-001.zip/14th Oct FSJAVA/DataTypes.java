
public class DataTypes {

	public static void main(String[] args) {
		
		double a=0;
		double b=0;
		double c=a/b;
		//System.out.println(c);
		
		byte num1=45;
		double num2;
		num2=num1;
		
		//System.out.println(num2);
		
		double d=45.5;
		byte e;
		
		e=(byte) d;
		System.out.println(e);
		
		
		byte ab=10;
		byte ac=20;
		int result = ab*ac;
		System.out.println(result);
		
		
		
		
	}

}
